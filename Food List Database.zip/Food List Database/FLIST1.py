import sqlite3

CREATE_FOODS_TABLE = "CREATE TABLE IF NOT EXISTS " \
                     "foods (id INTEGER PRIMARY KEY, name TEXT, preparation TEXT, rating INTEGER);"

INSERT_FOOD = "INSERT INTO foods (name, preparation, rating) VALUES (?, ?, ?);"

GET_ALL_FOODS = "SELECT * FROM foods;"
GET_FOODS_BY_NAME = "SELECT * FROM foods WHERE name = ?;"
GET_COOKING_METHOD_FOR_FOOD = """
SELECT * FROM foods 
WHERE name = ?
ORDER BY rating DESC
LIMIT 1"""
DELETE = "DELETE FROM foods WHERE name = ?;"


def connect():
    return sqlite3.connect("foods.db")


def create_tables(connection):
    with connection:
        connection.execute(CREATE_FOODS_TABLE)


def add_food(connection, name, preparation, rating):
    with connection:
        connection.execute(INSERT_FOOD, (name, preparation, rating))


def get_all_foods(connection):
    with connection:
        return connection.execute(GET_ALL_FOODS).fetchall()


def get_foods_by_name(connection, name):
    with connection:
        return connection.execute(GET_FOODS_BY_NAME, (name,)).fetchall()


def get_cooking_method_for_food(connection, name):
    with connection:
        return connection.execute(GET_COOKING_METHOD_FOR_FOOD, (name,)).fetchone()


def delete_food(connection, name):
    with connection:
        connection.execute(DELETE, (name,))
