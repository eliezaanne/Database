import FLIST1

MENU_LIST = """ -- FOOD LIST --

Please choose one of these options:

1) Add new food.
2) See all foods.
3) Find food by name.
4) See which cooking method is best for food.
5) Delete Food 
6) Exit

Your Selection: """


def menu():
    connection = FLIST1.connect()
    FLIST1.create_tables(connection)

    while (user_input := input(MENU_LIST)) != "6":
        if user_input == "1":
            prompt_add_new_food(connection)
        elif user_input == "2":
            prompt_see_all_foods(connection)
        elif user_input == "3":
            prompt_find_food(connection)
        elif user_input == "4":
            prompt_cooking_method(connection)
        elif user_input == "5":
            prompt_delete_method(connection)
        else:
            print("Invalid Input, Try Again!")


def prompt_add_new_food(connection):
    name = input("Enter food name: ")
    preparation = input("Enter cooking method: ")
    rating = int(input("Enter rating from (1-100): "))

    FLIST1.add_food(connection, name, preparation, rating)


def prompt_see_all_foods(connection):
    foods = FLIST1.get_all_foods(connection)

    for foods in foods:
        print(f"{foods[1]} ({foods[2]}) - {foods[3]}/100")


def prompt_find_food(connection):
    name = input("Enter food name to find: ")
    foods = FLIST1.get_foods_by_name(connection, name)

    for foods in foods:
        print(f"{foods[1]} ({foods[2]}) - {foods[3]}/100")


def prompt_cooking_method(connection):
    name = input("Enter food name to find: ")
    cooking_method = FLIST1.get_cooking_method_for_food(connection, name)

    print(f"The best cooking method for {name} is: {cooking_method[2]}.")


def prompt_delete_method(connection):
    name = input("Enter name to delete: ")

    print(f"The food id {name} has been deleted")
    FLIST1.delete_food(connection, name)

menu()
